import itertools
from collections import defaultdict

MIN_SUPPORT = 2

def read_transactions(filename):
    transactions = []
    with open(filename, 'r') as file:
        for line in file:
            items = list(map(int, line.strip().split()))
            transactions.append(set(items))
    return transactions

def generate_single_item_candidates(transactions):
    candidates = set()
    for transaction in transactions:
        for item in transaction:
            candidates.add(frozenset([item]))
    return candidates

def count_support(transactions, candidates):
    support_counts = defaultdict(int)
    for transaction in transactions:
        for candidate in candidates:
            if candidate.issubset(transaction):
                support_counts[candidate] += 1
    return support_counts

def filter_frequent_itemsets(support_counts, min_support):
    return {itemset for itemset, count in support_counts.items() if count >= min_support}

def generate_new_candidates(frequent_itemsets, size):
    candidates = set()
    frequent_itemsets_list = list(frequent_itemsets)
    for i in range(len(frequent_itemsets_list)):
        for j in range(i + 1, len(frequent_itemsets_list)):
            itemset1 = frequent_itemsets_list[i]
            itemset2 = frequent_itemsets_list[j]
            union = itemset1.union(itemset2)
            if len(union) == size:
                candidates.add(union)
    return candidates

def print_itemsets(support_counts, title, itemsets):
    print(f"{title}:")
    for itemset in itemsets:
        print(f"{set(itemset)} (support: {support_counts[itemset]})")
    print()

def apriori_algorithm(filename):
    transactions = read_transactions(filename)
    
    k = 1
    frequent_itemsets = set()
    current_candidates = generate_single_item_candidates(transactions)

    while current_candidates:
        support_counts = count_support(transactions, current_candidates)
        frequent_itemsets_current = filter_frequent_itemsets(support_counts, MIN_SUPPORT)

        if not frequent_itemsets_current:
            break

        print_itemsets(support_counts, f"Candidate itemsets of size {k}", current_candidates)
        print_itemsets(support_counts, f"Frequent itemsets of size {k}", frequent_itemsets_current)

        frequent_itemsets.update(frequent_itemsets_current)
        current_candidates = generate_new_candidates(frequent_itemsets, k + 1)
        k += 1

if __name__ == "__main__":
    filename = "input1.txt"
    apriori_algorithm(filename)
